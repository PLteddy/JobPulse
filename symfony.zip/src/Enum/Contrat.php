<?php

namespace App\Enum;

enum Contrat : string 
{
    case STAGE = 'STAGE';
    case ALTERNANCE = 'ALTERNANCE';

}
