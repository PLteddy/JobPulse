<?php

namespace App\Enum;

enum Type_presence : string 
{
    case PRESENTIEL = 'PRESENTIEL';
    case DISTANCIEL = 'DISTANCIEL';
    case HYBRIDE = 'HYBRIDE';

}
